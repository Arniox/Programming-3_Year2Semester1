
package bookstore;

import java.sql.ResultSet;

public class BookStoreMain {

    public static void main(String[] args) {
 
        BookStore bookstore=new BookStore();

      


    }

}
